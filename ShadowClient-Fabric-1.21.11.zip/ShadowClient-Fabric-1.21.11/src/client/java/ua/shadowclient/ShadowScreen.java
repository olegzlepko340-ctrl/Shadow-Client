package ua.shadowclient;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class ShadowScreen extends Screen {
    public ShadowScreen() {
        super(Component.literal("SHADOW CLIENT"));
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        this.renderBackground(graphics, mouseX, mouseY, delta);

        int panelWidth = 260;
        int panelHeight = 170;
        int left = (this.width - panelWidth) / 2;
        int top = (this.height - panelHeight) / 2;

        graphics.fill(left, top, left + panelWidth, top + panelHeight, 0xF0181818);
        graphics.fill(left, top, left + panelWidth, top + 3, 0xFF8A45FF);
        graphics.drawCenteredString(this.font, "SHADOW CLIENT", this.width / 2, top + 18, 0xFFFFFFFF);
        graphics.drawCenteredString(this.font, "Fabric 1.21.11", this.width / 2, top + 38, 0xFFB98CFF);
        graphics.drawString(this.font, "Client HUD: starter build", left + 18, top + 70, 0xFFE0E0E0);
        graphics.drawString(this.font, "More safe utility modules coming soon", left + 18, top + 88, 0xFFB0B0B0);
        graphics.drawCenteredString(this.font, "Press ESC or RIGHT SHIFT to close", this.width / 2, top + 140, 0xFFAAAAAA);

        super.render(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
